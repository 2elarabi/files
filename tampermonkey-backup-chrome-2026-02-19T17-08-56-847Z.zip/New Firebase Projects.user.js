// ==UserScript==
// @name         New Firebase Projects
// @namespace    http://tampermonkey.net/
// @version      2026-02-13
// @description  try to take over the world!
// @author       You
// @match        https://console.firebase.google.com/u/0
// @match        https://console.firebase.google.com/u/0/
// @match        https://console.firebase.google.com
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

function setNativeValue(element, value) {
    const lastValue = element.value;
    element.value = value;

    const event = new Event("input", { bubbles: true });
    // React 17+ special handling
    const tracker = element._valueTracker;
    if (tracker) {
        tracker.setValue(lastValue);
    }

    element.dispatchEvent(event);
}

    async function Closebtn(selector, proj_idd){
        let fnd = true;
        let inc = 0
        while (fnd == true) {
            console.log('inc_close: ', inc)
            let cont = document.querySelectorAll(selector);
            if(cont.length > 0){
                console.log('inc_close_+: ', inc)
                window.location.href = "https://console.firebase.google.com/project/"+proj_idd+"/authentication"
                fnd = false
            }
            inc++;
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before retry
        }
    }

    async function Getbtn_(selector, proj_idd){
        let fnd = true;
        let inc = 0
        while (fnd == true) {
            console.log('inc_btn: ', inc)
            //let cont = document.querySelectorAll(selector);
            const ell = Array.from(document.querySelectorAll('span[aria-live="polite"]'))
            .find(e => e.textContent.includes("Your Firebase project is ready") || e.textContent.includes("Votre projet Firebase est prêt"));

            //if(cont.length > 0){
            if(ell){
                let cont = document.querySelectorAll(selector);
                if(cont.length > 0 || inc > 10){
                    console.log('++++++++++++++++++++++++++++++++++++++')
                    console.log('inc_btn+++: ', inc)
                    console.log('cont.length: ', cont.length)
                    await Closebtn('[class="mdc-icon-button mat-mdc-icon-button mat-mdc-button-base mat-mdc-tooltip-trigger close-button mat-unthemed"]', proj_idd)
                    //cont[0].click();
                    fnd = false
                }
            }
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before retry
            inc++
        }
    }

    async function Getbtn(selector){
        let fnds = true;
        let incs = 0
        while (fnds == true) {
            console.log('inc_btn: ', incs)
            let conts = document.querySelectorAll(selector);
            if(conts.length > 0){
                console.log('inc_btn+++: ', incs)
                conts[0].click();
                //Closebtn('[class="mdc-icon-button mat-mdc-icon-button mat-mdc-button-base mat-mdc-tooltip-trigger close-button mat-unthemed"]')
                fnds = false
            }
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before retry
        }
        console.log('=============================================')
    }
    function randomString(length = 9) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    function setCookie(name, value, days = 7) {
        const maxAge = days * 24 * 60 * 60;
        document.cookie = `${name}=${value}; max-age=${maxAge}; path=/; SameSite=Lax`;
    }
    async function GetOrg(selector){
        let fnds = true;
        let incs = 0
        while (fnds == true) {
            console.log('inc_btn: ', incs)
            let conts = document.querySelectorAll(selector);
            if(conts.length > 2){
                console.log('org: ')
                //conts[0].click();
                //Closebtn('[class="mdc-icon-button mat-mdc-icon-button mat-mdc-button-base mat-mdc-tooltip-trigger close-button mat-unthemed"]')
                fnds = false
            }
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before
        }
        console.log('=============================================')
    }
console.log('start')
setTimeout(()=>{
    console.log('7 seconds passed')
    //document.getElementById('welcome-title').click()
    document.querySelector('button[class="action-card-body a11y-unstyled ng-star-inserted"],[data-test-id="create-project-card"],[id="welcome-title"]').click()
    setTimeout(()=>{
        console.log('1')
        //setNativeValue(document.getElementById('projectName'), "readqzssdy")
        setTimeout(async ()=>{
            console.log('2')
            await GetOrg('[cdk-describedby-host]')
            let proj_id = 'new-arb' + randomString().toLowerCase()
            setCookie('project_id', proj_id, 7)
            setNativeValue(document.getElementById('projectName'), proj_id)
            setTimeout(()=>{
                console.log('3')
                //document.querySelector('[class="mat-mdc-menu-item mat-focus-indicator analytics-account ng-star-inserted"]').click()
                document.querySelector('button[type="submit"]').click()
                setTimeout(()=>{
                    console.log('4')
                    document.querySelector('button[type="submit"]').click()
                    setTimeout(()=>{
                        console.log('5')
                        document.querySelector('button[type="submit"]').click()
                        setTimeout(()=>{
                            console.log('6')
                            document.getElementById('createProjectAnalyticsAccountInput').click()
                            setTimeout(async ()=>{
                                console.log('7')
                                await Getbtn('[class="mat-mdc-menu-item mat-focus-indicator analytics-account ng-star-inserted"]')
                                /*
                                let analy = document.querySelectorAll('[class="mat-mdc-menu-item mat-focus-indicator analytics-account ng-star-inserted"]')
                                console.log('length: ', analy.length)
                                analy[0].click()
                                */
                                document.querySelector('button[type="submit"]').click()
                                await Getbtn_('button[class="mdc-button mat-mdc-button-base success-confirm-button mdc-button--raised mat-mdc-raised-button mat-primary"]', proj_id)

                            }, 2000)
                        }, 1000)
                    }, 1000)
                }, 1000)
            }, 5000)
        })
    }, 2000)
}, 7000)

})();