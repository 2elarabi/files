// ==UserScript==
// @name         select project and go to his general page
// @namespace    http://tampermonkey.net/
// @version      2026-02-15
// @description  select project and go to his general page
// @author       You
// @match        https://console.firebase.google.com/u/0/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(async function() {
    'use strict';
    async function Closebtn(selector){
        let fnd = true;
        let inc = 0
        while (fnd == true) {
            let cont = document.querySelectorAll(selector);
            if(cont.length > 0){
                console.log('inc_close: ', cont.length)
                fnd = false
            }
            await new Promise(r => setTimeout(r, 2000)); // wait 2 sec before retry
        }
    }
    function getCookie(name) {
        const cookies = document.cookie.split("; ");
        for (let cookie of cookies) {
            const [key, value] = cookie.split("=");
            if (key === name) return value;
        }
        return null;
    }

    function setCookie(name, value, days = 7) {
        const maxAge = days * 24 * 60 * 60;
        document.cookie = `${name}=${value}; max-age=${maxAge}; path=/; SameSite=Lax`;
    }

    function updateProjectCookie() {
        let value = getCookie("project");

        if (value === null) {
            setCookie("project", 1);
            /*
            let ent = document.querySelectorAll('landing-entity-table-row');
            let project_id = ent[0].querySelector('.entity-table-subtitle').innerText
            */
            let project_list_ = getCookie("project_list").split(',');
            let project_id = project_list_[0]
            setCookie("project_id", project_id);
            let url = "https://console.firebase.google.com/project/" + project_id + "/settings/general"
            window.location.href = url
        } else {
            const newValue = parseInt(value, 10) + 1;
            setCookie("project", newValue);
            /*
            let ent = document.querySelectorAll('landing-entity-table-row');
            let project_id = ent[value].querySelector('.entity-table-subtitle').innerText
            */
            let project_list_ = getCookie("project_list").split(',');
            let project_id = project_list_[value]
            setCookie("project_id", project_id);
            let url = "https://console.firebase.google.com/project/" + project_id + "/settings/general"
            window.location.href = url
        }
    }
    function getTotalPages(totalArticles, perPage = 10) {
        return Math.ceil(totalArticles / perPage);
    }
    await Closebtn('landing-entity-table-row');

    let project_list = getCookie("project_list");
    if(project_list === null){
        const text_paginator = document.querySelector('.mat-mdc-paginator-range-label').innerText;
        const numbers = text_paginator.match(/\d+/g);

        const total = numbers ? parseInt(numbers[numbers.length - 1]) : 0;
        let total_pages = getTotalPages(total)
        project_list = "";
        let ent = document.querySelectorAll('landing-entity-table-row');
        for(let yy=0; yy < ent.length; yy++){
            if(yy == (ent.length - 1)){
                project_list = project_list + ent[yy].querySelector('.entity-table-subtitle').innerText + ","
            }
            else{
                project_list = project_list + ent[yy].querySelector('.entity-table-subtitle').innerText + ","
            }
        }
        if(total > 1){
            for(let y_y=0; y_y < (total_pages-1); y_y++){
                try{
                    document.querySelector('[aria-label="Page suivante"]').click()
                }catch{
                    document.querySelector('[aria-label="Next page"]').click()
                }
                await Closebtn('landing-entity-table-row');
                ent = document.querySelectorAll('landing-entity-table-row');
                for(let yy_=0; yy_ < ent.length; yy_++){
                    if(yy_ == (ent.length - 1)){
                        project_list = project_list + ent[yy_].querySelector('.entity-table-subtitle').innerText + ","
                    }
                    else{
                        project_list = project_list + ent[yy_].querySelector('.entity-table-subtitle').innerText + ","
                    }
                }
                console.log(`project_list${y_y}: `, project_list)
            }
        }
        setCookie("project_list", project_list);
        console.log('project_list_final', project_list)
        updateProjectCookie();
    }else {
        updateProjectCookie();
    }

    //updateProjectCookie();
    // Your code here...
})();