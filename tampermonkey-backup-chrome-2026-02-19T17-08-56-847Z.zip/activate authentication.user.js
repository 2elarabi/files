// ==UserScript==
// @name         activate authentication
// @namespace    http://tampermonkey.net/
// @version      2026-02-15
// @description  try to take over the world!
// @author       You
// @match        https://console.firebase.google.com/*/project/*/authentication*
// @match        https://console.firebase.google.com/project/*/authentication*
// @match        https://console.firebase.google.com/project/*/settings/general*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(async function() {
    'use strict';
    function getCookie(name) {
        const cookies = document.cookie.split("; ");
        for (let cookie of cookies) {
            const [key, value] = cookie.split("=");
            if (key === name) return value;
        }
        return null;
    }

    function setCookie(name, value, days = 7) {
        const maxAge = days * 24 * 60 * 60;
        document.cookie = `${name}=${value}; max-age=${maxAge}; path=/; SameSite=Lax`;
    }
    function updateProjectCookie() {
        let value = getCookie("user_accou");

        if (value === null) {
            let user = document.querySelector('[href*="https://accounts.google.com/SignOutOptions"]').getAttribute('aria-label').split('\n')[1].replace('(', '').replace(')', '')
            setCookie("user_accou", user);
        }
    }
    function setNativeValue_(element, value) {
        const lastValue = element.value;
        element.value = value;

        const event = new Event("input", { bubbles: true });
        // React 17+ special handling
        const tracker = element._valueTracker;
        if (tracker) {
            tracker.setValue(lastValue);
        }

        element.dispatchEvent(event);
    }
    async function getElement_(selector){
        let fnd = true;
        let inc = 0
        while (fnd == true) {
            console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
            console.log('inc: ', inc)
            let cont = document.querySelectorAll(selector);
            if(cont.length > 1){
                console.log('=======================================================')
                //let tt = getElement_('[class="fire-code-block c5e-code-block"]', 1, 1)

                const text = cont[1].innerText
                if (text.trim() != "") {
                    let user_accou = getCookie("user_accou")
                    //const text = document.querySelectorAll('[class="fire-code-block c5e-code-block"]')[1].innerText
                    // 2️⃣ Match ONLY the object with regex
                    const regex = /\{\s*\n\s*apiKey:[\s\S]*?\n\s*\};/;
                    const match = text.match(regex);

                    if (!match) {
                        throw new Error("Firebase config not found");
                    }

                    let jsObject = match[0];

                    // 3️⃣ Convert matched JS object → valid JSON
                    function jsObjectToJson(str) {
                        // 1️⃣ Normalize input
                        str = str
                            .replace(/^[^{]*\{/, "{")
                            .replace(/\};\s*$/, "}")
                            .replace(/[\u00A0]/g, " ");

                        // 2️⃣ Protect string values
                        const strings = [];
                        str = str.replace(/"(?:\\.|[^"])*"/g, m => {
                            strings.push(m);
                            return `__STR_${strings.length - 1}__`;
                        });

                        // 3️⃣ Quote keys ONLY
                        str = str.replace(/([^\s:{]+)\s*:/g, '"$1":');

                        // 4️⃣ Restore string values
                        str = str.replace(/__STR_(\d+)__/g, (_, i) => strings[i]);

                        return str.trim();
                    }


                    const jsonString = jsObjectToJson(jsObject);
                    console.log("JSON STRING:\n", jsonString);
                    const jsonObject = JSON.parse(jsonString);

                    const url = "https://jrhehjzezkqfldsjromt.supabase.co/functions/v1/insert-fb-project";
                    const firebaseConfig = jsonObject;
                    await fetch(url, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(firebaseConfig)
                    })
                        .then(res => res.json())
                        .then(data => {
                        console.log("Response:", data);
                    })
                        .catch(err => {
                        console.error("Error:", err);
                    });

                    /*
                    // 4️⃣ Export JSON file
                    function exportJsonFile(data, filename = (getCookie("project_id") + "_" + getCookie("user_accou") + "_firebaseConfig.json")) {
                        const blob = new Blob(
                            [JSON.stringify(data, null, 2)],
                            { type: "application/json" }
                        );

                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = filename;
                        a.click();

                        URL.revokeObjectURL(url);
                    }

                    // 5️⃣ Download
                    exportJsonFile(jsonObject);
                    */
                    setTimeout(()=>{
                        //document.querySelector('button[class="mdc-button mat-mdc-button-base mdc-button--raised mat-mdc-raised-button mat-primary ng-star-inserted"]').click()
                        setTimeout(()=>{
                            window.location.href= "https://console.firebase.google.com/u/0"
                        }, 3000)
                    }, 5000)
                    fnd = false
                }
                await new Promise(r => setTimeout(r, 2000)); // wait 2 sec before retry
            }
        }
    }
    async function wait(time){
        await new Promise(r => setTimeout(r, time)); // wait 2 sec before retry
    }
    async function Closebtn(selector){
        let fnd = true;
        let inc = 0
        while (inc < 3) {
            console.log('inc_close: ', inc)
            let cont = document.querySelectorAll(selector);
            if(cont.length > 0){
                console.log('inc_close: ', cont.length)
                inc = 10
                fnd = false
            }
            inc++;
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before retry
        }
    }

    let project_id = getCookie("project_id")
    if(window.location.href.includes('authentication')){
        console.log('phase 1')
        await Closebtn('button[color="primary"]')
        console.log("ddddddddddddd")
        let get_st = true
        let get_inc = 0
        while(get_st == true){
            const started = Array.from(document.querySelectorAll('button[color="primary"]'))
            .find(e => e.textContent.includes("Get started") || e.textContent.includes("Commencer"));
            if(started){
                started.click()
                get_st = false
            }else if(get_inc == 10){
                get_st = false
            }
            get_inc++;
            await wait(2000)
        }

        await Closebtn('div[role="button"]')
        console.log("qqqqqqq")
        get_st = true
        get_inc = 0
        while(get_st == true){
            const started_ = Array.from(document.querySelectorAll('div[role="button"]'))
            .find(e => e.textContent.includes("Email/Password") || e.textContent.includes("Adresse e-mail/Mot de passe"));
            //console.log('ssss: ', started_)
            if(started_){
                //started_.click()
                get_st = false
                window.location.href = "https://console.firebase.google.com/project/"+project_id+"/settings/general"
                /*
                setTimeout(()=>{
                    window.location.href = 'https://console.firebase.google.com/u/0'
                }, 2000)
                */
            }else if(get_inc == 10){
                get_st = false
            }else {
                //window.location.href = "https://console.firebase.google.com/project/"+project_id+"/settings/general"
            }
            await wait(1000)
        }
        try{
            await Closebtn('[aria-labelledby="emailLinkLabel"]')
            document.querySelector('[aria-labelledby="emailLinkLabel"]').click()
            await Closebtn('[type="submit"]')
            document.querySelector('[type="submit"]').click()
            setTimeout(()=>{
                let general_url = "https://console.firebase.google.com/project/"+project_id+"/settings/general"
                window.location.href = general_url
            }, 2000)
        }
        catch{
            let general_url = "https://console.firebase.google.com/project/"+project_id+"/settings/general"
            window.location.href = general_url
        }
    }
    else if(window.location.href.includes('settings/general')){
        console.log('phase 2')
        updateProjectCookie()
        console.log('phase 3')
        await Closebtn('[data-test-id="create-web-app"]')
        console.log('phase 4')
        setTimeout(async()=>{
            try{
                document.querySelector('[data-test-id="create-web-app"]').click()
                setTimeout(async()=>{
                    await Closebtn('[class*="fire-input-field"]')
                    let myApp = true
                    let myApp_inc = 0
                    while (myApp == true){
                        if(myApp_inc == 3){
                            myApp = false
                        }
                        myApp_inc++
                        await wait(1000)
                    }
                    setNativeValue_(document.querySelector('[class*="fire-input-field"]'), "myApp")
                    await Closebtn('button[type="submit"]')
                    document.querySelector('button[type="submit"]').click()
                    await getElement_('[class="fire-code-block c5e-code-block"]')
                }, 2000)
            }catch{
                await getElement_('[class="fire-code-block c5e-code-block"]')
            }
        }, 5000)
    }
    // Your code here...
})();