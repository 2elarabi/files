
(() => {
  "use strict";

  const VERSION = "SKU-QUEUE-3";

  if (window.__aliSqlCollectorRunning) {
    console.warn("[Ali SQL Collector] Already running.");
    return;
  }

  const SKU_ROW_SELECTOR = "[data-sku-row]";
  const OPTION_SELECTOR = "[data-sku-col]";
  const CURRENT_PRICE_SELECTOR =
    '[class*="price-default--current--"]';
  const ORIGINAL_PRICE_SELECTOR =
    '[class*="price-default--original--"]';

  const MAX_COMBINATIONS = 40;
  const ROW_WAIT_TIMEOUT = 15000;
  const OPTION_TIMEOUT = 4000;
  const PRICE_TIMEOUT = 5000;

  const sleep = ms =>
    new Promise(resolve => setTimeout(resolve, ms));

  function cleanText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function getProductId() {
    const match = location.pathname.match(/\/item\/(\d+)(?:\.html)?/i);
    return match ? match[1] : null;
  }

  function cleanImageUrl(value) {
    if (!value) return null;

    try {
      const url = new URL(value, location.href);
      if (!/^https?:$/.test(url.protocol)) return null;
      url.search = "";
      url.hash = "";

      return url.href
        .replace(/_\d+x\d+(?:q\d+)?\.(?:jpg|jpeg|png|webp|avif)_?$/i, "")
        .replace(/_\.(?:jpg|jpeg|png|webp|avif)$/i, "");
    } catch {
      return null;
    }
  }

  function parsePrice(text) {
    if (!text) return null;

    const value = String(text).replace(/\s+/g, " ").trim();
    const match = value.match(
      /(?:US\s*\$\s*|\$\s*)([\d,]+(?:\.\d{1,2})?)/i
    );

    if (!match) return null;

    const price = Number(match[1].replace(/,/g, ""));
    return Number.isFinite(price) && price >= 0 ? price : null;
  }

  function getProductTitle() {
    const selectors = [
      ".title--wrap--UUHae_g",
      '[data-pl="product-title"]',
      'meta[property="og:title"]',
      'meta[name="title"]',
      "h1"
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (!el) continue;

      const raw = el.tagName === "META"
        ? el.content
        : el.innerText || el.textContent;

      const title = cleanText(raw).replace(
        /\s*-\s*AliExpress\s*\d*\s*$/i,
        ""
      );

      if (title) return title;
    }

    return "";
  }

  function getDescription() {
    return cleanText(
      document.querySelector('meta[name="description"]')?.content ||
      document.querySelector('[class*="description--"]')?.innerText ||
      document.querySelector("#product-description")?.innerText
    );
  }

  function getMainImages() {
    const selectors = [
      ".slider--wrap--dfLgmYD img",
      '[class*="slider--wrap"] img',
      '[class*="images-view"] img',
      'meta[property="og:image"]'
    ];

    const urls = [];

    for (const selector of selectors) {
      for (const el of document.querySelectorAll(selector)) {
        const raw = el.tagName === "META"
          ? el.content
          : el.currentSrc ||
            el.getAttribute("src") ||
            el.getAttribute("data-src");

        const url = cleanImageUrl(raw);
        if (url) urls.push(url);
      }

      if (urls.length) break;
    }

    return [...new Set(urls)];
  }

  function getCurrentPrice() {
    const el = document.querySelector(CURRENT_PRICE_SELECTOR);
    if (!el) return null;

    const text = cleanText(el.innerText || el.textContent);
    const price = parsePrice(text);

    return price === null ? null : { price, text };
  }

  function getOriginalPrice() {
    const el = document.querySelector(ORIGINAL_PRICE_SELECTOR);
    if (!el) return null;

    return parsePrice(el.innerText || el.textContent);
  }

  function getRows() {
    return [...document.querySelectorAll(SKU_ROW_SELECTOR)];
  }

  function getRowById(rowId) {
    return getRows().find(
      row => row.getAttribute("data-sku-row") === String(rowId)
    ) || null;
  }

  function getOptions(row) {
    return row ? [...row.querySelectorAll(OPTION_SELECTOR)] : [];
  }

  function getOptionById(rowId, optionId) {
    return getOptions(getRowById(rowId)).find(
      option => option.getAttribute("data-sku-col") === String(optionId)
    ) || null;
  }

  function isSelected(option) {
    if (!option) return false;

    const classes = String(option.className || "");

    return (
      classes.includes("sku-item--selected--") ||
      option.getAttribute("aria-checked") === "true" ||
      option.getAttribute("aria-pressed") === "true"
    );
  }

  function isSoldOut(option) {
    if (!option) return true;

    const classes = String(option.className || "");

    return (
      classes.includes("sku-item--soldOut--") ||
      classes.includes("sku-item--disabled--") ||
      option.getAttribute("aria-disabled") === "true"
    );
  }

  function getOptionInfo(option) {
    const img = option?.querySelector("img");

    const candidates = [
      img?.getAttribute("alt"),
      img?.getAttribute("title"),
      option?.getAttribute("title"),
      option?.getAttribute("aria-label"),
      option?.innerText,
      option?.textContent
    ];

    let name = "";

    for (const candidate of candidates) {
      const cleaned = cleanText(candidate);
      if (cleaned) {
        name = cleaned;
        break;
      }
    }

    const id = option?.getAttribute("data-sku-col") || null;

    if (!name) name = id || "Unknown option";

    return {
      id,
      name,
      image_url: cleanImageUrl(
        img?.currentSrc ||
        img?.getAttribute("src") ||
        img?.getAttribute("data-src")
      )
    };
  }

  function getGroupLabel(row, index) {
    const property = row.closest('[class*="sku-item--property"]');
    const title = property?.querySelector('[class*="sku-item--title"]');
    const text = cleanText(title?.innerText || title?.textContent);

    if (text) {
      const colon = text.indexOf(":");
      return colon >= 0
        ? text.slice(0, colon).trim() || `Option ${index + 1}`
        : text;
    }

    return `Option ${index + 1}`;
  }

  async function waitForRows(timeout = ROW_WAIT_TIMEOUT) {
    const start = Date.now();

    while (Date.now() - start < timeout) {
      if (getRows().length) return true;
      await sleep(250);
    }

    return getRows().length > 0;
  }

  function snapshotGroups() {
    return getRows()
      .map((row, index) => {
        const id = row.getAttribute("data-sku-row");

        const options = getOptions(row)
          .filter(option => {
            const optionId = option.getAttribute("data-sku-col");
            return optionId && !isSoldOut(option);
          })
          .map(getOptionInfo)
          .filter(option => option.id);

        return {
          id,
          label: getGroupLabel(row, index),
          options
        };
      })
      .filter(group => group.id && group.options.length);
  }

  function makeCombinations(groups) {
    let combinations = [{ picks: [] }];

    for (const group of groups) {
      const next = [];

      for (const combination of combinations) {
        for (const option of group.options) {
          next.push({
            picks: [
              ...combination.picks,
              { group, option }
            ]
          });

          if (next.length >= MAX_COMBINATIONS) break;
        }

        if (next.length >= MAX_COMBINATIONS) break;
      }

      combinations = next;

      if (
        !combinations.length ||
        combinations.length >= MAX_COMBINATIONS
      ) {
        break;
      }
    }

    return combinations;
  }

  async function waitForSelectedOption(
    rowId,
    optionId,
    timeout = OPTION_TIMEOUT
  ) {
    const start = Date.now();

    while (Date.now() - start < timeout) {
      if (isSelected(getOptionById(rowId, optionId))) return true;
      await sleep(100);
    }

    return false;
  }

  async function waitForStablePrice(timeout = PRICE_TIMEOUT) {
    const start = Date.now();
    let previousText = null;
    let stableCount = 0;
    let latest = null;

    while (Date.now() - start < timeout) {
      const current = getCurrentPrice();

      if (current) {
        latest = current;

        if (current.text === previousText) {
          stableCount++;
        } else {
          stableCount = 0;
        }

        if (stableCount >= 2) return current;
        previousText = current.text;
      }

      await sleep(250);
    }

    return latest;
  }

  async function selectCombination(combination) {
    const attributes = {};
    const names = [];
    let imageUrl = null;

    for (const pick of combination.picks) {
      const { group, option: originalOption } = pick;

      let option = getOptionById(group.id, originalOption.id);

      if (!option || isSoldOut(option)) {
        return {
          ok: false,
          reason: `Option unavailable: ${originalOption.id}`
        };
      }

      if (!isSelected(option)) {
        option.click();

        const selected = await waitForSelectedOption(
          group.id,
          originalOption.id
        );

        if (!selected) {
          return {
            ok: false,
            reason: `Selection timed out: ${originalOption.id}`
          };
        }

        await sleep(500);
      }

      option = getOptionById(group.id, originalOption.id);

      if (!option || !isSelected(option) || isSoldOut(option)) {
        return {
          ok: false,
          reason: `Selected option could not be verified: ${originalOption.id}`
        };
      }

      const info = getOptionInfo(option);
      const value = info.name || originalOption.name;

      attributes[group.label] = value;
      names.push(`${group.label}: ${value}`);

      if (!imageUrl && info.image_url) imageUrl = info.image_url;
    }

    return {
      ok: true,
      attributes,
      name: names.join(" | "),
      image_url: imageUrl
    };
  }

  async function collectVariants() {
    await waitForRows();

    const groups = snapshotGroups();

    if (!groups.length) {
      const current = await waitForStablePrice();

      if (!current) {
        throw new Error(
          "No SKU groups found and displayed price could not be read."
        );
      }

      return {
        variants: [{
          sku: `${getProductId()}-default`,
          name: "Default",
          price: current.price,
          original_price: getOriginalPrice(),
          image_url: getMainImages()[0] || null,
          attributes: { variant: "Default" },
          price_verified: true,
          sort_order: 0
        }],
        errors: []
      };
    }

    const combinations = makeCombinations(groups);
    const variants = [];
    const errors = [];
    const seen = new Set();

    for (let i = 0; i < combinations.length; i++) {
      const combination = combinations[i];
      const rawSku = combination.picks
        .map(pick => pick.option.id)
        .join("__");

      try {
        const selected = await selectCombination(combination);

        if (!selected.ok) {
          errors.push({ sku: rawSku, error: selected.reason });
          continue;
        }

        const current = await waitForStablePrice();

        if (!current) {
          errors.push({
            sku: rawSku,
            error: "Displayed price could not be verified."
          });
          continue;
        }

        if (seen.has(rawSku)) continue;
        seen.add(rawSku);

        variants.push({
          sku: `${getProductId()}-${rawSku}`,
          name: selected.name || rawSku,
          price: current.price,
          original_price: getOriginalPrice(),
          image_url: selected.image_url,
          attributes: selected.attributes,
          price_verified: true,
          sort_order: variants.length
        });
      } catch (error) {
        errors.push({
          sku: rawSku,
          error: String(error?.message || error)
        });
      }
    }

    return { variants, errors };
  }

  async function extractProduct() {
    const productId = getProductId();

    if (!productId) {
      throw new Error("Product ID not found in URL.");
    }

    const start = Date.now();

    while (Date.now() - start < 30000 && !getProductTitle()) {
      await sleep(300);
    }

    const title = getProductTitle();

    if (!title) throw new Error("Product title not found.");

    const collected = await collectVariants();
    const images = getMainImages();

    return {
      productId,
      product: {
        id: productId,
        product_id: productId,
        title,
        description: getDescription(),
        image_url:
          images[0] ||
          collected.variants.find(v => v.image_url)?.image_url ||
          null,
        images,
        category: null,
        active: true,
        sort_order: 0,
        variants: collected.variants
      },
      debug: {
        version: VERSION,
        url: location.href,
        productId,
        skuGroupCount: snapshotGroups().length,
        variantCount: collected.variants.length,
        errors: collected.errors
      }
    };
  }

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, response => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response || {});
        }
      });
    });
  }

  async function main() {
    const productId = getProductId();
    if (!productId) return;

    const state = await sendMessage({
      type: "SHOULD_EXTRACT",
      productId
    });

    if (!state.ok || !state.shouldExtract) {
      console.log(
        "[Ali SQL Collector] No matching active queue item.",
        productId
      );
      return;
    }

    window.__aliSqlCollectorRunning = true;

    try {
      const result = await extractProduct();

      console.log(
        "[Ali SQL Collector] Extraction complete:",
        result.debug
      );

      const response = await sendMessage({
        type: "PRODUCT_EXTRACTED",
        ...result
      });

      console.log("[Ali SQL Collector] Background response:", response);
    } catch (error) {
      const message = String(error?.message || error);

      console.error("[Ali SQL Collector] Extraction failed:", error);

      try {
        await sendMessage({
          type: "PRODUCT_FAILED",
          productId,
          error: message
        });
      } catch (sendError) {
        console.error(
          "[Ali SQL Collector] Could not report failure:",
          sendError
        );
      }
    } finally {
      window.__aliSqlCollectorRunning = false;
    }
  }

  main().catch(error => {
    console.error("[Ali SQL Collector] Startup error:", error);
    window.__aliSqlCollectorRunning = false;
  });
})();
