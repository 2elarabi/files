
"use strict";

const $ = (id) => document.getElementById(id);

let queue = [];
let currentJob = null;
let refreshTimer = null;

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response || {});
    });
  });
}

function getProductId(url) {
  if (!url) return "";

  const patterns = [
    /\/item\/(\d+)\.html/i,
    /\/item\/(\d+)(?:\.html)?/i,
    /[?&]productId=(\d+)/i
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }

  return "";
}

async function getActiveAliTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });

  const tab = tabs[0];

  if (!tab || !tab.id || !tab.url) {
    throw new Error("Could not find the active tab.");
  }

  if (!tab.url.startsWith("https://www.aliexpress.us/")) {
    throw new Error("Open an AliExpress product page in this tab first.");
  }

  return tab;
}

async function detectCurrentProduct() {
  try {
    const tab = await getActiveAliTab();
    $("productId").value = getProductId(tab.url);
    $("productTitle").value = tab.title || "";
  } catch (_) {
    $("productId").value = "";
    $("productTitle").value = "";
  }
}

function setStatus(message, type = "") {
  $("status").textContent = message;
  $("status").className =
    type === "error" ? "status-error" :
    type === "success" ? "status-success" : "";
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function renderQueue() {
  $("queueCount").textContent =
    `${queue.length} product${queue.length === 1 ? "" : "s"}`;

  if (!queue.length) {
    $("queue").innerHTML =
      '<div class="empty">Your product queue is empty.</div>';
    return;
  }

  $("queue").innerHTML = queue.map((item, index) => {
    const title = item.title || `Product ${item.id}`;
    const status = item.status || "queued";

    return `
      <div class="queue-item" data-index="${index}">
        <div class="queue-title">${escapeHTML(title)}</div>
        <div class="queue-meta">
          ID: ${escapeHTML(item.id)} · Status: ${escapeHTML(status)}
        </div>
        <div class="queue-controls">
          <input
            class="queue-price"
            type="number"
            min="0.01"
            step="0.01"
            value="${Number(item.maxPrice)}"
            aria-label="Maximum price for product ${escapeHTML(item.id)}"
          />
          <button class="secondary save-price" type="button">Save</button>
          <button class="remove-btn" type="button">Remove</button>
        </div>
      </div>`;
  }).join("");

  $("queue").querySelectorAll(".save-price").forEach((button) => {
    button.addEventListener("click", async () => {
      const row = button.closest(".queue-item");
      const index = Number(row.dataset.index);
      const value = Number(row.querySelector(".queue-price").value);

      if (!Number.isFinite(value) || value <= 0) {
        setStatus("Enter a maximum price greater than zero.", "error");
        return;
      }

      queue[index].maxPrice = value;
      await saveQueue();
      renderQueue();
      setStatus("Maximum price updated.", "success");
    });
  });

  $("queue").querySelectorAll(".remove-btn").forEach((button) => {
    button.addEventListener("click", async () => {
      const row = button.closest(".queue-item");
      const index = Number(row.dataset.index);

      queue.splice(index, 1);
      await saveQueue();
      renderQueue();
      setStatus("Product removed from queue.", "success");
    });
  });
}

async function saveQueue() {
  await chrome.storage.local.set({ aliSqlCollectorQueue: queue });
}

async function loadQueue() {
  const data = await chrome.storage.local.get("aliSqlCollectorQueue");
  queue = Array.isArray(data.aliSqlCollectorQueue)
    ? data.aliSqlCollectorQueue
    : [];
  renderQueue();
}

async function addCurrentProduct() {
  try {
    const tab = await getActiveAliTab();
    const id = $("productId").value.trim() || getProductId(tab.url);
    const title = $("productTitle").value.trim() || tab.title || "";
    const maxPrice = Number($("maxPrice").value);

    if (!/^\d+$/.test(id)) {
      throw new Error("No valid product ID found. Open an AliExpress product page.");
    }

    if (!Number.isFinite(maxPrice) || maxPrice <= 0) {
      throw new Error("Maximum price must be greater than zero.");
    }

    const existing = queue.find((item) => item.id === id);

    if (existing) {
      existing.maxPrice = maxPrice;
      existing.title = title || existing.title;
      existing.status = "queued";
      setStatus("Product already exists. Its maximum price was updated.", "success");
    } else {
      queue.push({
        id,
        title,
        maxPrice,
        status: "queued"
      });
      setStatus("Product added to queue.", "success");
    }

    await saveQueue();
    renderQueue();
  } catch (error) {
    setStatus(error.message || String(error), "error");
  }
}

async function refreshState() {
  try {
    const response = await sendMessage({ type: "GET_STATE" });

    if (!response.ok) return;

    currentJob = response.job || null;

    if (Array.isArray(response.queue)) {
      queue = response.queue;
      renderQueue();
    }

    const job = currentJob;
    const total = job?.items?.length || 0;
    const done = job?.completedCount || 0;
    const percent = total ? Math.min(100, (done / total) * 100) : 0;

    $("progress").textContent = `${done} / ${total} processed`;
    $("progressBar").style.width = `${percent}%`;

    if (job) {
      setStatus(
        job.message ||
        `Job status: ${job.status}`,
        job.status === "error" ? "error" :
        job.status === "completed" ? "success" : ""
      );

      $("pauseResume").disabled =
        !["running", "paused"].includes(job.status);

      $("pauseResume").textContent =
        job.status === "paused" ? "Resume" : "Pause";

      $("retryFailed").disabled =
        !job.items?.some((item) => item.status === "failed");

      $("uploadStatus").textContent =
        `Upload: ${job.uploadStatus || "waiting"}`;

      $("retryUpload").disabled =
        !(job.sql && job.uploadStatus === "failed");
    } else {
      $("pauseResume").disabled = true;
      $("retryFailed").disabled = true;
      $("retryUpload").disabled = true;
    }

    const stored = await chrome.storage.local.get("aliSqlCollectorSQL");
    $("sql").value = stored.aliSqlCollectorSQL || "";

    const hasSQL = Boolean($("sql").value.trim());
    $("copySQL").disabled = !hasSQL;
    $("downloadSQL").disabled = !hasSQL;
  } catch (error) {
    setStatus(error.message || String(error), "error");
  }
}

async function startAll() {
  try {
    if (!queue.length) {
      throw new Error("Add at least one product first.");
    }

    const tab = await getActiveAliTab();

    const response = await sendMessage({
      type: "START_JOB",
      tabId: tab.id,
      items: queue.map((item) => ({
        id: item.id,
        title: item.title || "",
        maxPrice: Number(item.maxPrice)
      }))
    });

    if (!response.ok) {
      throw new Error(response.error || "Could not start collection.");
    }

    setStatus("Collection started.", "success");
    await refreshState();
  } catch (error) {
    setStatus(error.message || String(error), "error");
  }
}

async function togglePauseResume() {
  if (!currentJob) return;

  const type = currentJob.status === "paused" ? "RESUME_JOB" : "PAUSE_JOB";
  const response = await sendMessage({ type });

  if (!response.ok) {
    setStatus(response.error || "Could not change job status.", "error");
  }

  await refreshState();
}

async function retryFailed() {
  const response = await sendMessage({ type: "RETRY_FAILED" });

  if (!response.ok) {
    setStatus(response.error || "Could not retry failed products.", "error");
  }

  await refreshState();
}

async function clearQueue() {
  if (currentJob && ["running", "paused"].includes(currentJob.status)) {
    setStatus("Pause or finish the running job before clearing the queue.", "error");
    return;
  }

  queue = [];
  await saveQueue();
  renderQueue();
  setStatus("Queue cleared.", "success");
}

async function copySQL() {
  const sql = $("sql").value;

  if (!sql.trim()) return;

  try {
    await navigator.clipboard.writeText(sql);
    setStatus("SQL copied to clipboard.", "success");
  } catch (_) {
    $("sql").focus();
    $("sql").select();
    setStatus("Select the SQL and copy it manually.", "error");
  }
}

async function downloadSQL() {
  const sql = $("sql").value;
  if (!sql.trim()) return;

  const blob = new Blob([sql], { type: "text/sql;charset=utf-8" });
  const reader = new FileReader();

  reader.onload = async () => {
    try {
      await chrome.downloads.download({
        url: reader.result,
        filename: "aliexpress-products.sql",
        saveAs: true
      });
    } catch (error) {
      setStatus(error.message || String(error), "error");
    }
  };

  reader.readAsDataURL(blob);
}

async function retryUpload() {
  const response = await sendMessage({ type: "RETRY_UPLOAD" });

  if (!response.ok) {
    setStatus(response.error || "Could not retry upload.", "error");
  }

  await refreshState();
}

document.addEventListener("DOMContentLoaded", async () => {
  $("addProduct").addEventListener("click", addCurrentProduct);
  $("startAll").addEventListener("click", startAll);
  $("pauseResume").addEventListener("click", togglePauseResume);
  $("retryFailed").addEventListener("click", retryFailed);
  $("clearQueue").addEventListener("click", clearQueue);
  $("copySQL").addEventListener("click", copySQL);
  $("downloadSQL").addEventListener("click", downloadSQL);
  $("retryUpload").addEventListener("click", retryUpload);

  await detectCurrentProduct();
  await loadQueue();
  await refreshState();

  refreshTimer = setInterval(refreshState, 2000);
});

window.addEventListener("unload", () => {
  if (refreshTimer) clearInterval(refreshTimer);
});
