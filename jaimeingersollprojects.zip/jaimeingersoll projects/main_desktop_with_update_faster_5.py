import os
import json
import secrets
import threading
from itertools import cycle
from queue import Queue, Empty
from concurrent.futures import ThreadPoolExecutor
import requests
from colorama import Fore, init

import firebase_admin
from firebase_admin import credentials, auth, tenant_mgt
from supabase import create_client
from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession, Request

"""
pip install firebase-admin requests supabase google-auth google-auth-httplib2 google-auth-oauthlib colorama
python main_desktop_with_update_faster_5.py
"""

# ------------------ INIT ------------------
init(autoreset=True)
queue = Queue(maxsize=2000)
notify_lock = threading.Lock()

# ------------------ CONFIG ------------------
config = None

# Load all projects
with open("lawah.json", "r") as f:
    all_projects = json.load(f)["projects"]

# Show available projects
print("Available projects:")
for idx, p in enumerate(all_projects, start=1):
    print(f"{idx}. {p['name']} ({p['PD']})")

# Ask user to choose one
while True:
    try:
        choice = int(input("Select a project number: "))
        if 1 <= choice <= len(all_projects):
            config = all_projects[choice - 1]
            break
        else:
            print("Invalid choice")
    except ValueError:
        print("Enter a number")

if config is None:
    raise Exception("No project selected")

SUPABASE_URL = config["SUPABASE_URL"]
SUPABASE_KEY = config["SUPABASE_KEY"]
PROJECT_ID = config["PD"]
API_KEY = config["A_K"]
SERVICE_ACCOUNT_FILE = config["SERVICE_ACCOUNT_FILE"]
OF_ID = config.get("OF_ID", 15)
EMAILS_PER_BATCH = config.get("EMAILS_PER_BATCH", 1000)
CYCLES_TO_RUN = config.get("CYCLES_TO_RUN", 1)
TEMPLATE_CONFIG_FILE = "template_config.json"
MONITOR_EMAIL = config.get("MONITOR_EMAIL", "monitor@yourdomain.com")
TEMP_PASSWORD = config.get("TEMP_PASSWORD", "TempPass123!")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

# ------------------ FIREBASE ------------------
cred = credentials.Certificate(SERVICE_ACCOUNT_FILE)
firebase_admin.initialize_app(cred)

SCOPES = ["https://www.googleapis.com/auth/identitytoolkit"]
sa_creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES
)
authed_session = AuthorizedSession(sa_creds)
TENANTS_URL = f"https://identitytoolkit.googleapis.com/v2/projects/{PROJECT_ID}/tenants"

tenant_cycle = None
tenant_lock = threading.Lock()
auth_clients = {}

# ------------------ EMAIL COUNT TRACKER ------------------
tenant_email_count = {}  # tenant_id → emails sent

# ================== TEMPLATE SELECTION ==================
def choose_template_from_config():
    if not os.path.exists(TEMPLATE_CONFIG_FILE):
        print(Fore.RED + f"❌ Template config file '{TEMPLATE_CONFIG_FILE}' not found")
        return None, None, None

    with open(TEMPLATE_CONFIG_FILE, "r", encoding="utf-8") as f:
        templates = json.load(f)

    if not templates:
        print(Fore.RED + "❌ No templates defined in config")
        return None, None, None

    print("\n📂 Available Templates:")
    for idx, t in enumerate(templates, start=1):
        print(f"{idx}. File: {t['file']}, Subject: {t['subject']}, Sender: {t['sender_name']}")

    while True:
        try:
            choice = int(input("\nSelect template number: "))
            if 1 <= choice <= len(templates):
                selected = templates[choice-1]
                break
            else:
                print("Invalid choice.")
        except ValueError:
            print("Enter a valid number.")

    # Read HTML content from file
    template_path = selected["file"]
    if not os.path.exists(template_path):
        print(Fore.RED + f"❌ Template HTML file '{template_path}' not found")
        return None, None, None

    with open(template_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    return html_content, selected["subject"], selected["sender_name"]

def update_project_template(html_content, subject, sender_name):
    sa_creds.refresh(Request())
    access_token = sa_creds.token

    url = f'https://identitytoolkit.googleapis.com/admin/v2/projects/{PROJECT_ID}/config'
    data = {
        'notification': {
            'sendEmail': {
                'resetPasswordTemplate': {
                    'subject': subject,
                    'body': html_content,
                    'bodyFormat': 'HTML',
                    'senderDisplayName': sender_name
                }
            }
        }
    }
    params = {'updateMask': 'notification.sendEmail.resetPasswordTemplate'}
    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

    r = requests.patch(url, params=params, json=data, headers=headers)
    if r.status_code in (200, 204):
        print(Fore.GREEN + "✅ Project email template updated successfully!")
    else:
        print(Fore.RED + f"❌ Failed to update template: {r.status_code} - {r.text}")

# ================== TENANT FUNCTIONS ==================
def get_all_tenants():
    tenants, page_token = [], None
    while True:
        url = f"{TENANTS_URL}?pageSize=100"
        if page_token:
            url += f"&pageToken={page_token}"
        r = authed_session.get(url).json()
        tenants.extend(r.get("tenants", []))
        page_token = r.get("nextPageToken")
        if not page_token:
            break
    return tenants

def ensure_missing_tenants(wanted_count):
    tenants = get_all_tenants()
    existing_count = len(tenants)
    print(f"🏢 Existing tenants: {existing_count}, Wanted: {wanted_count}")
    if existing_count >= wanted_count:
        print("✅ Enough tenants exist, skipping creation.")
        return tenants
    missing = wanted_count - existing_count
    print(f"➕ Creating {missing} missing tenants...")
    for i in range(missing):
        display_name = f"auto-tenant-{existing_count + i + 1}"
        payload = {"displayName": display_name,"allowPasswordSignup": True,"enableEmailLinkSignin": False}
        r = authed_session.post(TENANTS_URL,json=payload)
        if r.status_code in (200,201):
            tid = r.json()["name"].split("/")[-1]
            print(Fore.GREEN + f"✅ Created tenant {tid}")
        else:
            print(Fore.RED + f"❌ Failed to create {display_name}: {r.text}")
    return get_all_tenants()

def update_template_inheritance(tenant_id):
    sa_creds.refresh(Request())
    access_token = sa_creds.token
    url_ = f"{TENANTS_URL}/{tenant_id}"
    headers_ = {'Authorization': f'Bearer {access_token}','Content-Type':'application/json'}
    params = {'updateMask':'inheritance.emailSendingConfig'}
    data_ = {'inheritance':{'emailSendingConfig':True}}
    r = requests.patch(url_, json=data_, headers=headers_, params=params)
    if r.status_code == 200:
        print(Fore.GREEN + f"✅ Template inheritance updated for tenant {tenant_id}")
    else:
        print(Fore.RED + f"❌ Failed inheritance update {tenant_id}: {r.text}")

# ================== MONITOR USER ==================
def recreate_monitor_user():
    try:
        try:
            user = auth.get_user_by_email(MONITOR_EMAIL)
            auth.delete_user(user.uid)
            #print(Fore.YELLOW + "⚠ Monitor user deleted")
        except auth.UserNotFoundError:
            pass
        auth.create_user(email=MONITOR_EMAIL,password=TEMP_PASSWORD)
        #print(Fore.GREEN + "✔ Monitor user recreated")
        return True
    except Exception as e:
        print(Fore.RED + f"✖ Monitor recreate failed: {e}")
        return False

def send_reset_via_api():
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={API_KEY}"
    payload = {"requestType":"PASSWORD_RESET","email":MONITOR_EMAIL}
    try:
        r = requests.post(url,json=payload,timeout=10)
        if r.status_code==200:
            #print(Fore.GREEN + "📧 Monitor Firebase reset email sent")
            return True
        else:
            #print(Fore.RED + f"✖ Monitor reset failed: {r.text}")
            return False
    except Exception as e:
        print(Fore.RED + f"✖ Monitor reset error: {e}")
        return False

def send_monitor_notification():
    with notify_lock:
        if recreate_monitor_user():
            return send_reset_via_api()
        return False

# ================== EMAIL LOGIC ==================
supabase_call_count = 0

def fetch_emails(batch_size):
    global supabase_call_count
    supabase_call_count += 1
    print(Fore.YELLOW + f"🔄 Supabase RPC called {supabase_call_count} time(s)")
    try:
        r = supabase.rpc(
            "get_100_emails_and_insert",
            {"p_table": "gmx_tenant_users", "p_offer_id": OF_ID, "p_limit": batch_size}
        ).execute()

        emails = [row["email"] for row in (r.data or []) if row.get("email")]
        if not emails:
            #print(Fore.YELLOW + "⚠ No emails returned from Supabase this cycle")
            pass
        for e in emails:
            #print("e: ", e)
            queue.put(e)
        return len(emails)
    except Exception as e:
        #print(Fore.RED + f"❌ Supabase RPC error: {e}")
        return 0

def add_user_and_send_reset(tenant_id,email):
    client = tenant_mgt.auth_for_tenant(tenant_id)
    try:
        client.create_user(email=email,password=secrets.token_urlsafe(12),email_verified=False)
        #print(Fore.CYAN + f"👤 Created {email} (tenant {tenant_id})")
    except:
        #print(Fore.YELLOW + f"👤 Exists {email} (tenant {tenant_id})")
        pass

    url = f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={API_KEY}"
    payload = {"requestType":"PASSWORD_RESET","email":email,"tenantId":tenant_id}
    try:
        r = requests.post(url,json=payload,timeout=10)
        if r.status_code==200:
            #print(Fore.GREEN + f"✅ SENT {email} (tenant {tenant_id})")
            print(Fore.GREEN + f"✅ SUCCESSFULLY SENT {email}")
        else:
            print(Fore.RED + f"❌ FAILED {email} | {r.text}")
    except Exception as e:
        print(Fore.RED + f"✖ ERROR {email} (tenant {tenant_id}) | {e}")

    # ================== MONITOR NOTIFICATION ==================
    tenant_email_count[tenant_id] = tenant_email_count.get(tenant_id,0)+1
    if tenant_email_count[tenant_id] >= 1000:
        print(Fore.MAGENTA + f"🚨 1000 emails sent for tenant {tenant_id}, sending monitor notification...")
        send_monitor_notification()
        tenant_email_count[tenant_id] = 0

# ================== WORKER ==================
def get_next_tenant():
    with tenant_lock:
        return next(tenant_cycle)

def tenant_worker():
    while True:
        try:
            email = queue.get(timeout=3)
        except Empty:
            return
        tenant_id = get_next_tenant()
        try:
            add_user_and_send_reset(tenant_id,email)
        finally:
            queue.task_done()

# ================== MAIN ==================
def main():
    wanted_count = int(input("Enter number of tenants you want: "))
    update_templates_flag = input("Update project template? (y/n): ").strip().lower() == "y"

    # 1️⃣ Ensure tenants
    tenants = ensure_missing_tenants(wanted_count)
    tenant_ids = [t["name"].split("/")[-1] for t in tenants]

    # 2️⃣ Update template if requested
    if update_templates_flag:
        html_content, subject, sender_name = choose_template_from_config()
        if html_content:
            update_project_template(html_content, subject, sender_name)
        for tid in tenant_ids:
            update_template_inheritance(tid)

    # 3️⃣ Setup tenant rotation
    global tenant_cycle
    tenant_cycle = cycle(tenant_ids)

    # 4️⃣ Start workers
    max_workers = (os.cpu_count() or 4) * 2
    print(Fore.CYAN + f"Starting {max_workers} worker threads")
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        for _ in range(max_workers):
            pool.submit(tenant_worker)

        # 5️⃣ Fetch emails in cycles from config
        for batch in range(1, CYCLES_TO_RUN + 1):
            fetched = fetch_emails(EMAILS_PER_BATCH)
            #print(Fore.CYAN + f"🔥 Batch {batch} → {fetched} emails fetched")
            queue.join()

    print(Fore.CYAN + "✅ All done!")

if __name__=="__main__":
    main()