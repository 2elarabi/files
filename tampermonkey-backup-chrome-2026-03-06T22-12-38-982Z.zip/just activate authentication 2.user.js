// ==UserScript==
// @name         just activate authentication 2
// @namespace    http://tampermonkey.net/
// @version      2026-02-15
// @description  try to take over the world!
// @author       You
// @match        https://console.firebase.google.com/project/*/authentication*
// @match        https://console.firebase.google.com/*/project/*/authentication*
// @match        https://console.firebase.google.com/project/*/authentication/providers*
// @match        https://console.firebase.google.com/project/*/settings/general*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(async function() {
    'use strict';
    function getCookie(name) {
        const cookies = document.cookie.split("; ");
        for (let cookie of cookies) {
            const [key, value] = cookie.split("=");
            if (key === name) return value;
        }
        return null;
    }

    function setCookie(name, value, days = 7) {
        const maxAge = days * 24 * 60 * 60;
        document.cookie = `${name}=${value}; max-age=${maxAge}; path=/; SameSite=Lax`;
    }
    function updateProjectCookie() {
        let value = getCookie("user_accou");

        if (value === null) {
            let user = document.querySelector('[href*="https://accounts.google.com/SignOutOptions"]').getAttribute('aria-label').split('\n')[1].replace('(', '').replace(')', '')
            setCookie("user_accou", user);
        }
    }
    async function Closebtn(selector){
        let fnd = true;
        let inc = 0
        while (inc < 5) {
            console.log('inc_close: ', inc)
            let cont = document.querySelectorAll(selector);
            if(cont.length > 0){
                console.log('inc_close: ', cont.length)
                inc = 10
                fnd = false
            }
            inc++;
            await new Promise(r => setTimeout(r, 1000)); // wait 2 sec before retry
        }
    }

    let project_id = getCookie("project_id")
    if(window.location.href.includes('authentication')){
        let value = getCookie("project");
        let project_list_ = getCookie("project_list").split(',');
        let url = ""
        if (value === null) {
            setCookie("project", 1);
            let project_id = project_list_[0]
            setCookie("project_id", project_id);
            url = "https://console.firebase.google.com/project/" + project_id + "/authentication/providers"
        }
        else {
            const newValue = parseInt(value, 10) + 1;
            setCookie("project", newValue);
            let project_id = project_list_[value]
            setCookie("project_id", project_id);
            url = "https://console.firebase.google.com/project/" + project_id + "/authentication/providers"
        }
        console.log('phase 1')
        await Closebtn('button[color="primary"]')
        console.log("ddddddddddddd")
        const started = Array.from(document.querySelectorAll('button[color="primary"]'))
        .find(e => e.textContent.includes("Get started") || e.textContent.includes("Commencer"));
        if(started){
            started.click()
        }

        await Closebtn('div[role="button"]')
        console.log("qqqqqqq")
        const started_ = Array.from(document.querySelectorAll('div[role="button"]'))
        .find(e => e.textContent.includes("Email/Password") || e.textContent.includes("Adresse e-mail/Mot de passe"));
        console.log('ssss: ', started_)
        if(started_){
            started_.click()
            setTimeout(()=>{
                window.location.href = url
            }, 2000)
        }else {
            window.location.href = url
        }
    }
    // Your code here...
})();